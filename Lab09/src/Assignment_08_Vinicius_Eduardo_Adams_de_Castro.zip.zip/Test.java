import java.util.Arrays;

public class Test {
    public static void main (String[]args){
        Module [] a ={
                new Module("OP","Paddy",34),
                new Module("CH","Alan",26)
        };
    }

    //Arrays.sort(a);
//System.out.println("");
//Sorting all the employee
    //Arrays.sort(a,Module.lectCompare);

}
